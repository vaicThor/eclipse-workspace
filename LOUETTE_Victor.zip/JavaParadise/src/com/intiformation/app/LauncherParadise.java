package com.intiformation.app;

import com.intiformation.app.dao.service.PlaceService;
import com.intiformation.app.interactive.InteractiveManager;
import com.intiformation.app.model.Place;

public final class LauncherParadise {


	public static void main(String[] args) {
		InteractiveManager im = new InteractiveManager();
		im.interactive();

	}

}
