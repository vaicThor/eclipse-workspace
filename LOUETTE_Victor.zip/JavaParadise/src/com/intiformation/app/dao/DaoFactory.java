package com.intiformation.app.dao;

import com.intiformation.app.dao.jdbc.JdbcPlaceDAO;
import com.intiformation.app.dao.jdbc.JdbcTripDAO;

public class DaoFactory {

	
	
	
	// constructor private
	private DaoFactory() {}
	
	// Methods
	public static JdbcTripDAO getTripDao() {
		JdbcTripDAO jd = new JdbcTripDAO();
		return jd ;
	}
	
	public static JdbcPlaceDAO getPlaceDao() {
		JdbcPlaceDAO jd = new JdbcPlaceDAO();
		return jd ;
	}
}
